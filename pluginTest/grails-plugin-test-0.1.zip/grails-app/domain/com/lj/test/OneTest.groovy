package com.lj.test

class OneTest {
    String name;
    String passWord;
    static constraints = {
    }
}
